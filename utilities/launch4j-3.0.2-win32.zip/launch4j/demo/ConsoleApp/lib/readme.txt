Put your jar libs here and the build script will include them
in the classpath stored inside the jar manifest.
In order to run your application move the output exe file from
the dist directory to the same level as lib. 

SimpleApp.exe
lib/
lib/xml.jar
